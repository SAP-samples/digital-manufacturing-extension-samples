import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.slurpersupport.GPathResult;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
	String oriPayload = message.getProperty("originalBody")
    GPathResult oriRoot = new XmlSlurper().parseText(oriPayload);
    Set<String> requestsFields = ["VarianceReasonCode",
                "Personnel"];
    Map nodes = [:]
    System.out.println("123")


	Reader payload = message.getBody(java.io.Reader);
	GPathResult root = new XmlSlurper().parse(payload);
	
		List<GPathResult> searchResult = root.'**'.findAll { GPathResult it -> requestsFields.contains(it.name()) && it.children().size() == 0; }
		if (!searchResult.isEmpty()) {
			
            searchResult.each { GPathResult it ->
    			nodes[it.name()] = it.toString();
    		}
		}
    
    def code = nodes.get("VarianceReasonCode")
    def id = nodes.get("Personnel")
    def reasonCode = {VarianceReasonCode "$code"}
    def persId = {Personnel "$id"}

    List<GPathResult> srcResult = oriRoot.'**'.findAll { GPathResult it -> it.name().equals("ProdnOrdConf2Type"); }
		if (!srcResult.isEmpty()) {
			srcResult.each{ GPathResult it ->
				it.leftShift(reasonCode);
                it.leftShift(persId);
			}
           
		}

	message.setBody(XmlUtil.serialize(oriRoot));
	return message;
}
