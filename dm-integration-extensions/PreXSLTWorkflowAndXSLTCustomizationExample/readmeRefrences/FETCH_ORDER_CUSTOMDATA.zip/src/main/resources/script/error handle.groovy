import com.sap.gateway.ip.core.customdev.util.Message
import org.codehaus.groovy.runtime.InvokerHelper
import groovy.util.slurpersupport.GPathResult
import groovy.xml.XmlUtil

def Message processData(Message message) {
	
    def props = message.getProperties()
    String oriPayload = message.getProperty("originalBody")
	
	message.setBody(oriPayload);
	return message
}